// ============================================================
//  ASTI Robotics Challenge - TIRABOLOS  (AUTÓNOMO)
//  Robot: OSOYOO M2.0 Mecanum  /  Arduino Mega 2560
//  IDE:  Arduino IDE 2.3.7
//
//  ENTORNO:
//    - Lona blanca con círculo negro de 2 m de diámetro
//    - 6 bolos plásticos (24 cm, 60 g) dentro del círculo
//    - Robot parte sobre marca dentro del círculo
//
//  ESTRATEGIA:
//    1) Barrido ultrasónico con servo para localizar el bolo
//       más cercano.
//    2) Giro Mecanum en sitio hasta encarar el bolo.
//    3) Embestida hacia delante.
//    4) STOP inmediato cuando cualquiera de los 5 sensores de
//       línea detecta el borde negro: el bolo cruza, nosotros no.
//    5) Retroceso al centro y nuevo barrido.
//
//  PUNTUACIÓN: +5 puntos * bolos derribados + bonus por tiempo
//  si se sacan los 6. Foco: completitud antes que velocidad.
// ============================================================

#include <Arduino.h>
#include <Servo.h>

// ---------- TIPOS ----------
// El struct DEBE ir antes de cualquier función que lo devuelva por valor.
// Sin esto el IDE de Arduino genera un prototipo arriba antes de conocer
// el tipo y compilar falla con "'Scan' does not name a type".
struct Scan { bool found; int servoAngle; long dist; };

// ---------- LIBRERÍA MECANUM ----------
#define FR_IN1 22
#define FR_IN2 24
#define FL_IN1 26
#define FL_IN2 28
#define FR_PWM 10
#define FL_PWM  9
#define RR_IN1  5
#define RR_IN2  6
#define RL_IN1  7
#define RL_IN2  8
#define RR_PWM 11
#define RL_PWM 12
#define INVERT_FR false
#define INVERT_FL false
#define INVERT_RR false
#define INVERT_RL false

void setMotor(int in1,int in2,int pwm,int s,bool inv){
  if(inv) s=-s;
  if(s>0){digitalWrite(in1,HIGH);digitalWrite(in2,LOW);}
  else if(s<0){digitalWrite(in1,LOW);digitalWrite(in2,HIGH);s=-s;}
  else{digitalWrite(in1,LOW);digitalWrite(in2,LOW);}
  analogWrite(pwm,constrain(s,0,255));
}
void mecanumDrive(int vx,int vy,int w){
  long fl=(long)vx+vy+w, fr=(long)vx-vy-w, rl=(long)vx-vy+w, rr=(long)vx+vy-w;
  long m=max(max(abs(fl),abs(fr)),max(abs(rl),abs(rr)));
  if(m>255){fl=fl*255/m; fr=fr*255/m; rl=rl*255/m; rr=rr*255/m;}
  setMotor(FL_IN1,FL_IN2,FL_PWM,fl,INVERT_FL);
  setMotor(FR_IN1,FR_IN2,FR_PWM,fr,INVERT_FR);
  setMotor(RL_IN1,RL_IN2,RL_PWM,rl,INVERT_RL);
  setMotor(RR_IN1,RR_IN2,RR_PWM,rr,INVERT_RR);
}
inline void stopMotors(){ mecanumDrive(0,0,0); }
inline void moveForward(int s){ mecanumDrive(s,0,0); }
inline void moveBackward(int s){ mecanumDrive(-s,0,0); }
inline void rotateCW(int s){ mecanumDrive(0,0,s); }
inline void rotateCCW(int s){ mecanumDrive(0,0,-s); }
void setupMotors(){
  int p[]={FR_IN1,FR_IN2,FR_PWM,FL_IN1,FL_IN2,FL_PWM,
           RR_IN1,RR_IN2,RR_PWM,RL_IN1,RL_IN2,RL_PWM};
  for(int x:p) pinMode(x,OUTPUT);
}

// ---------- SENSORES ----------
#define TRIG_PIN 30
#define ECHO_PIN 31
#define SERVO_PIN 13
#define LINE_1 A4
#define LINE_2 A3
#define LINE_3 A2
#define LINE_4 A1
#define LINE_5 A0

// >>> CALIBRAR: lectura analógica encima de la línea NEGRA.
// Con TCRT5000 OSOYOO: blanco ~ 100-300, negro ~ 700-1000.
// Pon un umbral entre ambos. Usa el Serial Monitor para fijarlo.
#define LINE_BLACK_THRESHOLD 600

Servo head;

// ---------- PARÁMETROS DE JUEGO ----------
#define ATTACK_SPEED    230
#define SEARCH_SPEED    150
#define TURN_SPEED      170
#define BACK_SPEED      180
#define MS_PER_DEG_TURN  9     // CALIBRAR: ms para girar 1º a TURN_SPEED
#define ATTACK_MAX_MS  2500    // máximo tiempo embestida antes de abortar
#define BACKOFF_MS      450    // ms de retroceso tras empujar
#define EDGE_BACK_MS    300    // ms de retroceso si vemos borde sin querer
#define START_DELAY_MS 3000    // segundos para retirar la mano

// ---------- LECTURAS ----------
long readDistanceCm() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  long dur = pulseIn(ECHO_PIN, HIGH, 25000UL); // 25 ms => ~4 m máx
  if (dur == 0) return 999;
  return (long)(dur * 0.0343 / 2.0);
}

bool anyLineBlack() {
  return (analogRead(LINE_1) > LINE_BLACK_THRESHOLD ||
          analogRead(LINE_2) > LINE_BLACK_THRESHOLD ||
          analogRead(LINE_3) > LINE_BLACK_THRESHOLD ||
          analogRead(LINE_4) > LINE_BLACK_THRESHOLD ||
          analogRead(LINE_5) > LINE_BLACK_THRESHOLD);
}

// ---------- BARRIDO ----------
Scan sweepForTarget() {
  Scan best = {false, 90, 999};
  // Barrido de 30º a 150º (120º útiles, evita ángulos extremos)
  for (int a = 30; a <= 150; a += 10) {
    head.write(a);
    delay(70);
    long d = readDistanceCm();
    // Filtro: solo objetos plausibles
    if (d > 8 && d < 180 && d < best.dist) {
      best.found = true;
      best.servoAngle = a;
      best.dist = d;
    }
  }
  head.write(90);
  delay(120);
  return best;
}

// Gira el chasis para encarar el ángulo del servo (90 = ya alineado)
void faceTarget(int servoAngle) {
  int delta = servoAngle - 90;  // [-60..+60]
  if (abs(delta) < 5) return;
  long t = (long)abs(delta) * MS_PER_DEG_TURN;
  if (delta > 0) rotateCW(TURN_SPEED);
  else           rotateCCW(TURN_SPEED);
  delay(t);
  stopMotors();
  delay(120);
}

// Embestida controlada: avanza hasta que un sensor de línea ve negro
// (borde del círculo) o se alcanza ATTACK_MAX_MS. Tras tocar borde,
// retrocede para no quedarse encima de la raya.
void chargeAndPush() {
  unsigned long t0 = millis();
  moveForward(ATTACK_SPEED);
  while (millis() - t0 < ATTACK_MAX_MS) {
    if (anyLineBlack()) break;
    delay(5);
  }
  stopMotors();
  delay(100);

  // Retrocede para volver a maniobrar dentro del círculo
  moveBackward(BACK_SPEED);
  delay(BACKOFF_MS);
  stopMotors();
  delay(150);
}

// Si por lo que sea estamos sobre la raya al iniciar un ciclo,
// retrocede un poco y reorienta.
void recoverFromEdge() {
  moveBackward(BACK_SPEED);
  delay(EDGE_BACK_MS);
  stopMotors();
  delay(100);
  rotateCW(TURN_SPEED);
  delay(40L * MS_PER_DEG_TURN);   // ~40º
  stopMotors();
  delay(100);
}

// ---------- SETUP / LOOP ----------
void setup() {
  setupMotors();
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  head.attach(SERVO_PIN);
  head.write(90);
  Serial.begin(115200);
  delay(START_DELAY_MS);
}

void loop() {
  // Safety primero: si tocamos borde, retrocede
  if (anyLineBlack()) { recoverFromEdge(); return; }

  Scan s = sweepForTarget();

  if (s.found) {
    faceTarget(s.servoAngle);
    chargeAndPush();
  } else {
    // No vemos nada -> giramos un poco y reintenta
    rotateCW(SEARCH_SPEED);
    delay(250);
    stopMotors();
    delay(120);
  }
}
