// ============================================================
//  ASTI Robotics Challenge - SUMO  (AUTÓNOMO, 1 vs 1)
//  Robot: OSOYOO M2.0 Mecanum  /  Arduino Mega 2560
//  IDE:  Arduino IDE 2.3.7
//
//  ENTORNO:
//    - Tatami 1.5 x 1.5 m, círculo negro de 1.1 m de diámetro
//    - Rival: robot estándar ASTI (~200 g)
//    - Salida: ESPALDA contra espalda  =>  hay que girar 180º
//    - Tiempo: 2 minutos máximo
//
//  ESTRATEGIA POR PUNTOS:
//    A) Combate inválido (no mover/salir solo) ............ 0 pts
//    B) Expulsa al rival ......................... 70 - t/5 pts
//    D) Permanece en el tatami todo el combate ........... 25 pts
//
//    Conclusión: si no encontramos rival rápido, la segunda
//    mejor opción es NO SALIRSE. El bucle prioriza anti-borde
//    sobre cualquier otra acción.
// ============================================================

#include <Arduino.h>
#include <Servo.h>

// ---------- TIPOS ----------
// IMPORTANTE: el struct DEBE quedar declarado antes de cualquier función
// que lo devuelva por valor. El IDE de Arduino auto-genera los prototipos
// arriba del archivo y, si Scan no existe todavía ahí, el compilador da
// "'Scan' does not name a type".
struct Scan { bool found; int servoAngle; long dist; };

// ---------- LIBRERÍA MECANUM ----------
#define FR_IN1 22
#define FR_IN2 24
#define FL_IN1 26
#define FL_IN2 28
#define FR_PWM 10
#define FL_PWM  9
#define RR_IN1  5
#define RR_IN2  6
#define RL_IN1  7
#define RL_IN2  8
#define RR_PWM 11
#define RL_PWM 12
#define INVERT_FR false
#define INVERT_FL false
#define INVERT_RR false
#define INVERT_RL false

void setMotor(int in1,int in2,int pwm,int s,bool inv){
  if(inv) s=-s;
  if(s>0){digitalWrite(in1,HIGH);digitalWrite(in2,LOW);}
  else if(s<0){digitalWrite(in1,LOW);digitalWrite(in2,HIGH);s=-s;}
  else{digitalWrite(in1,LOW);digitalWrite(in2,LOW);}
  analogWrite(pwm,constrain(s,0,255));
}
void mecanumDrive(int vx,int vy,int w){
  long fl=(long)vx+vy+w, fr=(long)vx-vy-w, rl=(long)vx-vy+w, rr=(long)vx+vy-w;
  long m=max(max(abs(fl),abs(fr)),max(abs(rl),abs(rr)));
  if(m>255){fl=fl*255/m; fr=fr*255/m; rl=rl*255/m; rr=rr*255/m;}
  setMotor(FL_IN1,FL_IN2,FL_PWM,fl,INVERT_FL);
  setMotor(FR_IN1,FR_IN2,FR_PWM,fr,INVERT_FR);
  setMotor(RL_IN1,RL_IN2,RL_PWM,rl,INVERT_RL);
  setMotor(RR_IN1,RR_IN2,RR_PWM,rr,INVERT_RR);
}
inline void stopMotors(){ mecanumDrive(0,0,0); }
inline void moveForward(int s){ mecanumDrive(s,0,0); }
inline void moveBackward(int s){ mecanumDrive(-s,0,0); }
inline void rotateCW(int s){ mecanumDrive(0,0,s); }
inline void rotateCCW(int s){ mecanumDrive(0,0,-s); }
void setupMotors(){
  int p[]={FR_IN1,FR_IN2,FR_PWM,FL_IN1,FL_IN2,FL_PWM,
           RR_IN1,RR_IN2,RR_PWM,RL_IN1,RL_IN2,RL_PWM};
  for(int x:p) pinMode(x,OUTPUT);
}

// ---------- SENSORES ----------
#define TRIG_PIN 30
#define ECHO_PIN 31
#define SERVO_PIN 13
#define LINE_1 A4
#define LINE_2 A3
#define LINE_3 A2
#define LINE_4 A1
#define LINE_5 A0
#define LINE_BLACK_THRESHOLD 600   // CALIBRAR sobre el tatami

Servo head;

// ---------- PARÁMETROS DE JUEGO ----------
#define ATTACK_SPEED   255
#define BACK_SPEED     200
#define TURN_SPEED     180
#define SEARCH_SPEED   140
#define ATTACK_DIST     50    // cm
#define LOST_DIST      120    // cm: por encima, "no veo nada"
#define TURN_180_MS    520    // ms para 180º a TURN_SPEED (CALIBRAR)
#define MS_PER_DEG_TURN  8    // ms/grado a TURN_SPEED (CALIBRAR)
#define ESCAPE_TIME    320    // ms retroceso al ver borde
#define START_DELAY_MS 3000

// ---------- LECTURAS ----------
long readDistanceCm() {
  digitalWrite(TRIG_PIN, LOW);  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  long dur = pulseIn(ECHO_PIN, HIGH, 20000UL);
  if (dur == 0) return 999;
  return (long)(dur * 0.0343 / 2.0);
}

bool anyLineBlack() {
  return (analogRead(LINE_1) > LINE_BLACK_THRESHOLD ||
          analogRead(LINE_2) > LINE_BLACK_THRESHOLD ||
          analogRead(LINE_3) > LINE_BLACK_THRESHOLD ||
          analogRead(LINE_4) > LINE_BLACK_THRESHOLD ||
          analogRead(LINE_5) > LINE_BLACK_THRESHOLD);
}

// ---------- ACCIONES ----------
void rotate180() {
  rotateCW(TURN_SPEED);
  delay(TURN_180_MS);
  stopMotors();
  delay(120);
}

void escapeEdge() {
  // Retrocede + gira ~60º para reposicionarse hacia el centro
  moveBackward(BACK_SPEED);
  delay(ESCAPE_TIME);
  stopMotors();
  delay(80);
  rotateCW(TURN_SPEED);
  delay(60L * MS_PER_DEG_TURN);
  stopMotors();
  delay(80);
}

// Barrido rápido buscando al rival.
Scan quickScan() {
  Scan best = {false, 90, 999};
  for (int a = 40; a <= 140; a += 20) {  // 6 puntos, rápido
    head.write(a);
    delay(50);
    long d = readDistanceCm();
    if (d > 5 && d < LOST_DIST && d < best.dist) {
      best.found = true; best.servoAngle = a; best.dist = d;
    }
  }
  head.write(90);
  return best;
}

// ---------- SETUP / LOOP ----------
void setup() {
  setupMotors();
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  head.attach(SERVO_PIN);
  head.write(90);
  delay(START_DELAY_MS);

  // Giro inicial 180º para encarar al rival (espalda con espalda)
  rotate180();
}

void loop() {
  // 1) Anti-borde tiene prioridad absoluta
  if (anyLineBlack()) { escapeEdge(); return; }

  // 2) Mirar de frente: si veo cerca, embisto sin escanear
  head.write(90);
  delay(30);
  long dFront = readDistanceCm();
  if (dFront > 5 && dFront < ATTACK_DIST) {
    moveForward(ATTACK_SPEED);
    unsigned long t0 = millis();
    while (millis() - t0 < 1500) {
      if (anyLineBlack()) break;
    }
    stopMotors();
    return;
  }

  // 3) Si no, barrido lateral
  Scan s = quickScan();
  if (s.found) {
    int delta = s.servoAngle - 90;
    if (abs(delta) > 8) {
      long t = (long)abs(delta) * MS_PER_DEG_TURN;
      if (delta > 0) rotateCW(TURN_SPEED);
      else           rotateCCW(TURN_SPEED);
      delay(t);
      stopMotors();
      delay(60);
    }
    // Tras alinearse, embiste
    moveForward(ATTACK_SPEED);
    unsigned long t0 = millis();
    while (millis() - t0 < 1200) {
      if (anyLineBlack()) break;
    }
    stopMotors();
  } else {
    // 4) Nadie a la vista -> giro de búsqueda lento
    rotateCW(SEARCH_SPEED);
    delay(180);
    stopMotors();
    delay(40);
  }
}
