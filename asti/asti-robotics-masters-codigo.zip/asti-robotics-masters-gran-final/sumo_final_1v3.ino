// ============================================================
//  ASTI Robotics Challenge - DESAFÍO FINAL SUMO  (1 vs 3, AUTÓNOMO)
//  Robot: OSOYOO M2.0 Mecanum  /  Arduino Mega 2560
//  IDE:  Arduino IDE 2.3.7
//
//  ENTORNO:
//    - Mismo tatami que SUMO (círculo 1.1 m)
//    - 3 rivales estándar ASTI dentro a la vez
//    - 2 min de calibración previos + 2 min combate
//    - Solo 1 enfrentamiento
//
//  DIFERENCIAS vs SUMO 1v1:
//    - NO se garantiza salida espalda-a-espalda => no giro 180º.
//    - Hay objetivos por todas partes: la búsqueda es más
//      corta y más agresiva.
//    - Conviene apuntar a clusters: si dos rivales están en línea,
//      una embestida puede sacar a los dos.
//    - Anti-borde sigue siendo prioritario: si nos sacan, fin.
//
//  ESQUEMA DEL LOOP:
//    1) Si pisamos negro -> retroceso + giro hacia centro.
//    2) Lectura frontal rápida: si rival cerca -> embestida full.
//    3) Si no, barrido y se ataca al MÁS CERCANO.
//    4) Si nada se ve, micro-giro y reintenta.
// ============================================================

#include <Arduino.h>
#include <Servo.h>

// ---------- TIPOS ----------
// El struct DEBE ir antes de cualquier función que lo devuelva por valor.
// Sin esto el IDE de Arduino genera un prototipo arriba antes de conocer
// el tipo y compilar falla con "'Scan' does not name a type".
struct Scan { bool found; int servoAngle; long dist; };

// ---------- LIBRERÍA MECANUM ----------
#define FR_IN1 22
#define FR_IN2 24
#define FL_IN1 26
#define FL_IN2 28
#define FR_PWM 10
#define FL_PWM  9
#define RR_IN1  5
#define RR_IN2  6
#define RL_IN1  7
#define RL_IN2  8
#define RR_PWM 11
#define RL_PWM 12
#define INVERT_FR false
#define INVERT_FL false
#define INVERT_RR false
#define INVERT_RL false

void setMotor(int in1,int in2,int pwm,int s,bool inv){
  if(inv) s=-s;
  if(s>0){digitalWrite(in1,HIGH);digitalWrite(in2,LOW);}
  else if(s<0){digitalWrite(in1,LOW);digitalWrite(in2,HIGH);s=-s;}
  else{digitalWrite(in1,LOW);digitalWrite(in2,LOW);}
  analogWrite(pwm,constrain(s,0,255));
}
void mecanumDrive(int vx,int vy,int w){
  long fl=(long)vx+vy+w, fr=(long)vx-vy-w, rl=(long)vx-vy+w, rr=(long)vx+vy-w;
  long m=max(max(abs(fl),abs(fr)),max(abs(rl),abs(rr)));
  if(m>255){fl=fl*255/m; fr=fr*255/m; rl=rl*255/m; rr=rr*255/m;}
  setMotor(FL_IN1,FL_IN2,FL_PWM,fl,INVERT_FL);
  setMotor(FR_IN1,FR_IN2,FR_PWM,fr,INVERT_FR);
  setMotor(RL_IN1,RL_IN2,RL_PWM,rl,INVERT_RL);
  setMotor(RR_IN1,RR_IN2,RR_PWM,rr,INVERT_RR);
}
inline void stopMotors(){ mecanumDrive(0,0,0); }
inline void moveForward(int s){ mecanumDrive(s,0,0); }
inline void moveBackward(int s){ mecanumDrive(-s,0,0); }
inline void rotateCW(int s){ mecanumDrive(0,0,s); }
inline void rotateCCW(int s){ mecanumDrive(0,0,-s); }
void setupMotors(){
  int p[]={FR_IN1,FR_IN2,FR_PWM,FL_IN1,FL_IN2,FL_PWM,
           RR_IN1,RR_IN2,RR_PWM,RL_IN1,RL_IN2,RL_PWM};
  for(int x:p) pinMode(x,OUTPUT);
}

// ---------- SENSORES ----------
#define TRIG_PIN 30
#define ECHO_PIN 31
#define SERVO_PIN 13
#define LINE_1 A4
#define LINE_2 A3
#define LINE_3 A2
#define LINE_4 A1
#define LINE_5 A0
#define LINE_BLACK_THRESHOLD 600   // CALIBRAR

Servo head;

// ---------- PARÁMETROS ----------
#define ATTACK_SPEED    255
#define BACK_SPEED      210
#define TURN_SPEED      190
#define SEARCH_SPEED    150
#define ATTACK_DIST      55     // un poco más generoso que 1v1
#define LOST_DIST       110
#define MS_PER_DEG_TURN   8     // CALIBRAR
#define ESCAPE_TIME     300
#define ATTACK_PUSH_MS 1300     // tiempo máximo empujando
#define START_DELAY_MS 3000

// ---------- LECTURAS ----------
long readDistanceCm() {
  digitalWrite(TRIG_PIN, LOW);  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  long dur = pulseIn(ECHO_PIN, HIGH, 20000UL);
  if (dur == 0) return 999;
  return (long)(dur * 0.0343 / 2.0);
}

bool anyLineBlack() {
  return (analogRead(LINE_1) > LINE_BLACK_THRESHOLD ||
          analogRead(LINE_2) > LINE_BLACK_THRESHOLD ||
          analogRead(LINE_3) > LINE_BLACK_THRESHOLD ||
          analogRead(LINE_4) > LINE_BLACK_THRESHOLD ||
          analogRead(LINE_5) > LINE_BLACK_THRESHOLD);
}

// ---------- ACCIONES ----------
void escapeEdge() {
  // Retrocede + giro hacia el centro
  moveBackward(BACK_SPEED);
  delay(ESCAPE_TIME);
  stopMotors();
  delay(60);
  rotateCW(TURN_SPEED);
  delay(70L * MS_PER_DEG_TURN);   // ~70º
  stopMotors();
  delay(60);
}

// Barrido amplio: cubre casi 180º. Devuelve el ÁNGULO más cercano
// donde se ve algo dentro de LOST_DIST.
Scan wideScan() {
  Scan best = {false, 90, 999};
  for (int a = 30; a <= 150; a += 15) {
    head.write(a);
    delay(45);
    long d = readDistanceCm();
    if (d > 5 && d < LOST_DIST && d < best.dist) {
      best.found = true; best.servoAngle = a; best.dist = d;
    }
  }
  head.write(90);
  return best;
}

void chargeForward() {
  unsigned long t0 = millis();
  moveForward(ATTACK_SPEED);
  while (millis() - t0 < ATTACK_PUSH_MS) {
    if (anyLineBlack()) break;
  }
  stopMotors();
  delay(70);
}

void turnToServo(int servoAngle) {
  int delta = servoAngle - 90;
  if (abs(delta) < 6) return;
  long t = (long)abs(delta) * MS_PER_DEG_TURN;
  if (delta > 0) rotateCW(TURN_SPEED);
  else           rotateCCW(TURN_SPEED);
  delay(t);
  stopMotors();
  delay(50);
}

// ---------- SETUP / LOOP ----------
void setup() {
  setupMotors();
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  head.attach(SERVO_PIN);
  head.write(90);
  delay(START_DELAY_MS);
  // No hay giro 180º inicial: la posición de inicio no es fija
}

void loop() {
  // 1) Anti-borde manda siempre
  if (anyLineBlack()) { escapeEdge(); return; }

  // 2) Lectura frontal: si hay rival muy cerca, no perdemos tiempo
  head.write(90);
  delay(25);
  long dFront = readDistanceCm();
  if (dFront > 5 && dFront < ATTACK_DIST) {
    chargeForward();
    return;
  }

  // 3) Barrido buscando al más cercano
  Scan s = wideScan();
  if (s.found) {
    turnToServo(s.servoAngle);
    chargeForward();
  } else {
    // 4) Sin contacto -> giro corto y reintenta
    rotateCW(SEARCH_SPEED);
    delay(150);
    stopMotors();
    delay(30);
  }
}
