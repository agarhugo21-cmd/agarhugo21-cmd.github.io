// ============================================================
//  ASTI Robotics Challenge - DIBUJA LA FIGURA  (AUTÓNOMO)
//  Sketch: TRIÁNGULO EQUILÁTERO de 25 cm de lado (perímetro=75 cm)
//  Robot: OSOYOO M2.0 Mecanum  /  Arduino Mega 2560
//
//  Estrategia: 3 lados de 25 cm + 2 giros externos de 120º CW.
//  El ángulo externo de un triángulo equilátero es 180-60 = 120º.
//  Tras el 3er lado el robot vuelve al origen y NO necesita girar.
// ============================================================

#include <Arduino.h>

// ---------- LIBRERÍA MECANUM ----------
#define FR_IN1 22
#define FR_IN2 24
#define FL_IN1 26
#define FL_IN2 28
#define FR_PWM 10
#define FL_PWM  9
#define RR_IN1  5
#define RR_IN2  6
#define RL_IN1  7
#define RL_IN2  8
#define RR_PWM 11
#define RL_PWM 12
#define INVERT_FR false
#define INVERT_FL false
#define INVERT_RR false
#define INVERT_RL false

void setMotor(int in1,int in2,int pwm,int s,bool inv){
  if(inv) s=-s;
  if(s>0){digitalWrite(in1,HIGH);digitalWrite(in2,LOW);}
  else if(s<0){digitalWrite(in1,LOW);digitalWrite(in2,HIGH);s=-s;}
  else{digitalWrite(in1,LOW);digitalWrite(in2,LOW);}
  analogWrite(pwm,constrain(s,0,255));
}
void mecanumDrive(int vx,int vy,int w){
  long fl=(long)vx+vy+w, fr=(long)vx-vy-w, rl=(long)vx-vy+w, rr=(long)vx+vy-w;
  long m=max(max(abs(fl),abs(fr)),max(abs(rl),abs(rr)));
  if(m>255){fl=fl*255/m; fr=fr*255/m; rl=rl*255/m; rr=rr*255/m;}
  setMotor(FL_IN1,FL_IN2,FL_PWM,fl,INVERT_FL);
  setMotor(FR_IN1,FR_IN2,FR_PWM,fr,INVERT_FR);
  setMotor(RL_IN1,RL_IN2,RL_PWM,rl,INVERT_RL);
  setMotor(RR_IN1,RR_IN2,RR_PWM,rr,INVERT_RR);
}
inline void stopMotors(){ mecanumDrive(0,0,0); }
inline void moveForward(int s){ mecanumDrive(s,0,0); }
inline void rotateCW(int s){ mecanumDrive(0,0,s); }
void setupMotors(){
  int p[]={FR_IN1,FR_IN2,FR_PWM,FL_IN1,FL_IN2,FL_PWM,
           RR_IN1,RR_IN2,RR_PWM,RL_IN1,RL_IN2,RL_PWM};
  for(int x:p) pinMode(x,OUTPUT);
}

// ---------- PARÁMETROS DE DIBUJO ----------
const int DRAW_SPEED      = 110;
const int TURN_SPEED      = 130;
const int MS_PER_CM_FWD   = 55;    // CALIBRAR
const int MS_PER_DEG_TURN = 10;    // CALIBRAR

const int SIDE_CM      = 25;
const int CORNER_DEG   = 120;      // ángulo externo equilátero
const int N_SIDES      = 3;
const int SETTLE_MS    = 250;
const int START_DELAY_MS = 3000;

void setup() {
  setupMotors();
  stopMotors();
  delay(START_DELAY_MS);

  for (int i = 0; i < N_SIDES; i++) {
    moveForward(DRAW_SPEED);
    delay((long)SIDE_CM * MS_PER_CM_FWD);
    stopMotors();
    delay(SETTLE_MS);

    if (i < N_SIDES - 1) {
      rotateCW(TURN_SPEED);
      delay((long)CORNER_DEG * MS_PER_DEG_TURN);
      stopMotors();
      delay(SETTLE_MS);
    }
  }
  stopMotors();
}

void loop() {}
